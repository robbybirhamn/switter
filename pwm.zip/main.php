<?php 
session_start(); 

//cek apakah sudah login
if(empty($_SESSION['user_login']))
{
    echo "<script>document.location.href='index.php'</script>";
}

//include koneksi
include "koneksi.php";

$userId = $_SESSION['user_login'];

//cek user login
$q_userData = mysqli_query($koneksi,"SELECT*from member WHERE id='$userId'");
$userData = mysqli_fetch_array($q_userData);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Switter - Stikubank Twitter</title>

    <link rel="shortcut icon" href="twitter.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/base.css">
</head>
<body>
    <!------------ Navigation Bar ------------>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <a href="#" class="navbar-brand">
                    <span style="color:#1DA1F2;font-weight:bold;" class="glyphicon glyphicon-chevron-right"></span>
                    <span style="color:#1DA1F2;font-weight:bold;">SWITTER</span>
                </a>

                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#nav-menu" aria-expanded="false">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <button id="tweet" class="btn btn-default pull-right visible-xs-block">
                    <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
                        Tweet
                </button>
            </div>

            <div id="nav-menu" class="collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="#">
                            <span class="glyphicon glyphicon-home" aria-hidden="true"></span>
                                Beranda
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="badge">2</span>
                            <span class="glyphicon glyphicon-bell" aria-hidden="true"></span>
                                Notifikasi
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="badge">0</span>
                            <span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
                                Pesan
                        </a>
                    </li>
                    <li class="visible-xs-inline">
                        <a href="#">
                            <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                                Profile
                        </a>
                    </li>
                    <li class="visible-xs-inline">
                        <a href="logout.php">
                            <span class="glyphicon glyphicon-off" aria-hidden="true" ></span>
                             Keluar
                        </a>
                    </li>
                </ul>

                <button id="tweet" class="btn btn-default pull-right hidden-xs">
                    <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
                        Tweet
                </button>

                <!------------- Options Button Dropdown  ------------->
                <div id="nav-options" class="btn-group pull-right hidden-xs">
                    <button type="button" class="btn btn-default dropdown-toggle thumbnail" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="imgs/<?= $userData['img'] ?>" alt="bos 01">
                    </button>
                    <ul class="dropdown-menu">
                        <li><a href="#">Profile</a></li>
                        <li><a href="#">Pengaturan</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="logout.php">Keluar</a></li>
                    </ul>
                </div>

                <form id="search" role="search" class="hidden-sm">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Cari disini.......">
                        <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
                    </div>
                </form>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div id="profile-resume" class="card" style="border-color:#15181C;">
                    <a href="#"><img class="card-img-top img-responsive" src="imgs/landscape.jpg"></a>
                    <div class="card-block" style="background:#15181C;color:white;">
                    <img src="imgs/<?= $userData['img'] ?>" class="card-img">
                    <h4 class="card-title"><?= $userData['name'] ?> <small><?= $userData['email'] ?></small></h4>
                    <p class="card-text"><?= $userData['biodata'] ?></p>
                    <ul class="list-inline list-unstyled">
                        <li id="card-tweets">
                        <a href="#">
                        <span class="profile-stats">Tweet</span>
                        <span class="profile-value">99k</span>
                        </a>
                        </li>
                        <li id="card=following">
                        <a href="#">
                        <span class="profile-stats">Following</span>
                        <span class="profile-value">7</span>
                        </a>
                        </li>
                        <li id="card=followers">
                        <a href="#">
                        <span class="profile-stats">Followers</span>
                        <span class="profile-value">132k</span>
                        </a>
                        </li>
                    </ul>
                    </div>
                    </div>

                    <div id="profile-photo" class="card" style="border-color:#15181C;">
                    <div class="card-header" style="border-color:#15181C;background:#15181C;color:white;">Dokumen Foto</div>
                    <div class="card-block" style="background:#15181C;color:white;">
                    <ul class="list-inline list-unstyled">
                        <?php
                        //galeri user login
                        $q_galeri = mysqli_query($koneksi,"SELECT*from galeri WHERE user_id='$userId'");
                        while($galeriData = mysqli_fetch_array($q_galeri))
                        {
                        ?>
                        <li>
                            <a href="imgs/<?= $galeriData['img'] ?>" class="thumbnail"><img class="img-responsive" src="imgs/<?= $galeriData['img'] ?>"></a>
                        </li>
                        <?php } ?>
                    </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <ol class="breadcrumb card" style="background:#15181C;color:white;border-color:#15181C;">
                    <li><a href="#">Beranda</a></li>
                    <li><a href="#">Profil</a></li>
                    <li class="active">Feed</li>
                </ol>

                <div id="main-card" class="card" style="border-color:#15181C;">
                    <?php
                    if(isset($_POST['tweet']))
                    {
                        $tweet = $_POST['tweet'];
                        //insert tweet to database
                        mysqli_query($koneksi,"INSERT into tweet (user_id,tweet)values('$userId','$tweet')");
                    }
                    ?>
                    <form id="new-message" method="POST" action="" style="background:#15181C;color:white;">
                        <div class="input-group">
                            <input type="text" class="form-control" name="tweet" placeholder="Tweet your ideas . . .">
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-camera" aria-hidden="true"></span>
                            </span>
                        </div>
                    </form>
                    <ul id="feed" class="list-unstyled" style="background:#15181C;color:white;border-color:#15181C;">
                        <?php
                        //menampilkan seluruh tweet terbaru
                        $q_tweet = mysqli_query($koneksi,"SELECT*from tweet JOIN member ON member.id=tweet.user_id ORDER BY time DESC");
                        while($tweetData = mysqli_fetch_array($q_tweet)){
                        ?>
                        <li style="border-color:#000;">
                            <img src="imgs/<?= $tweetData['img'] ?>" class="feed-avatar img-circle">
                            <div class="feed-post">
                                <h5><?= $tweetData['name'] ?> <small>@<?= $tweetData['username'] ?></small></h5>
                                <p><?= $tweetData['tweet'] ?></p>
                            </div>
                            <div class="action-list">
                                <a href="#">
                                    <span class="glyphicon glyphicon-share-alt" aria-hidden="true"></span>
                                </a>
                                <a href="#">
                                    <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
                                    <span class="retweet-count">6</span>
                                </a>
                                <a href="#">
                                    <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
                                </a>
                            </div>
                        </li>
                        <?php } ?>

                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div id="who-follow" class="card" style="border:none">
                    <div class="card-header" style="background:#15181C;color:white;">
                        On Radar
                    </div>
                    <div class="card-block" style="background:#15181C;color:white;">
                        <ul class="list-unstyled">
                            <?php
                            //menampilkan user selain kita
                            $q_memberu = mysqli_query($koneksi,"SELECT*from member WHERE id != '$userId'");
                            while($memberuData = mysqli_fetch_array($q_memberu))
                            {
                            ?>
                            <li>
                                <img src="imgs/<?= $memberuData['img'] ?>" class="img-rounded">
                                <div class="info">
                                    <strong><?= $memberuData['name'] ?></strong>
                                    <button class="btn btn default" style="background:#1DA1F2;">
                                        <span class="glyphicon glyphicon-plus" aria-hidden="true" style="color:white;"></span> Follow
                                    </button>
                                </div>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>

                <div id="app-info" class="card" style="background:#15181C;color:white;border:none;">
                    <div class="card-block">
                        @2020 Switter - Stikubank Twitter
                        <ul class="list-unstyled list-inline">
                            <li><a href="#">Tentang Kami</a></li>
                            <li><a href="#">Kebijakan dan Privasi</a></li>
                            <li><a href="#">Bantuan</a></li>
                            <li><a href="#">Status</a></li>
                            <li><a href="#">Kontak</a></li>
                        </ul>
                    </div>
                    <div class="card-footer" style="background:#15181C;color:white;">
                        <a href="#">Switter &copy; 2019</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="js/jquery-1.11.3.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/main.js"></script>
</body>
</html>